#!/bin/bash
echo "Running TARR Annunciator Updater..."
./tarr-updater
