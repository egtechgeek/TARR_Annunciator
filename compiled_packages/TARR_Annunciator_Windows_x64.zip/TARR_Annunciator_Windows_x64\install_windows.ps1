# TARR Annunciator Windows Installation Script (PowerShell) - Go Version
# Run with: PowerShell -ExecutionPolicy Bypass -File install_windows.ps1
# Alternative to install_windows.bat

Write-Host "===============================================" -ForegroundColor Cyan
Write-Host "TARR Annunciator Windows Installation (Go)" -ForegroundColor Cyan  
Write-Host "===============================================" -ForegroundColor Cyan

# Check if running as Administrator
$currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($isAdmin) {
    Write-Host "✓ Running with Administrator privileges" -ForegroundColor Green
    $adminRights = $true
} else {
    Write-Host "⚠ WARNING: Not running as Administrator" -ForegroundColor Yellow
    Write-Host "Service installation will not be available" -ForegroundColor Yellow
    Write-Host "Re-run as Administrator to enable Windows service installation" -ForegroundColor Yellow
    $adminRights = $false
}

# Check if executable exists
if (Test-Path "tarr-annunciator.exe") {
    Write-Host "✓ Found: tarr-annunciator.exe" -ForegroundColor Green
} else {
    Write-Host "✗ ERROR: tarr-annunciator.exe not found" -ForegroundColor Red
    Write-Host "Please ensure you have the pre-compiled Windows executable in this directory" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Check for required directories
$requiredDirs = @("json", "templates", "static", "logs")
foreach ($dir in $requiredDirs) {
    if (!(Test-Path $dir)) {
        Write-Host "Creating directory: $dir" -ForegroundColor Yellow
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    Write-Host "✓ Directory verified: $dir" -ForegroundColor Green
}

Write-Host "`nChecking Windows audio system..." -ForegroundColor Yellow
try {
    $audioDevices = Get-WmiObject -Class Win32_SoundDevice | Where-Object {$_.Status -eq 'OK'}
    if ($audioDevices) {
        Write-Host "✓ Windows audio devices detected" -ForegroundColor Green
    } else {
        Write-Host "⚠ WARNING: No Windows audio devices detected" -ForegroundColor Yellow
        Write-Host "Audio functionality may not work properly" -ForegroundColor Yellow
    }
} catch {
    Write-Host "⚠ WARNING: Could not check audio devices" -ForegroundColor Yellow
}

# Check for enhanced audio control module
Write-Host "Checking for AudioDeviceCmdlets PowerShell module..." -ForegroundColor Yellow
if (Get-Module -ListAvailable -Name AudioDeviceCmdlets) {
    Write-Host "✓ AudioDeviceCmdlets module found - full audio device control available" -ForegroundColor Green
} else {
    Write-Host "⚠ AudioDeviceCmdlets module not found - using WMI fallback for audio" -ForegroundColor Yellow
    Write-Host "To install enhanced audio control:" -ForegroundColor Cyan
    Write-Host "  Install-Module -Name AudioDeviceCmdlets -Force" -ForegroundColor White
}

Write-Host "`n===============================================" -ForegroundColor Cyan
Write-Host "Service Installation Options" -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Cyan

if ($adminRights) {
    $installService = Read-Host "Install TARR Annunciator as Windows service? (Y/N)"
    if ($installService -eq "Y" -or $installService -eq "y") {
        Write-Host "`nInstalling TARR Annunciator as Windows service..." -ForegroundColor Yellow
        
        $installDir = Get-Location
        $serviceName = "TARRAnnunciator"
        $serviceDisplayName = "TARR Annunciator Train Announcement System"
        
        # Create service wrapper script
        $wrapperContent = @"
@echo off
REM TARR Annunciator Windows Service Wrapper
cd /d "$installDir"
"$installDir\tarr-annunciator.exe"
"@
        $wrapperContent | Out-File -FilePath "$installDir\tarr-service.bat" -Encoding ASCII
        Write-Host "✓ Service wrapper script created" -ForegroundColor Green
        
        # Install service
        try {
            $result = sc.exe create $serviceName binPath= "`"$installDir\tarr-service.bat`"" DisplayName= $serviceDisplayName start= auto
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✓ Service installed successfully!" -ForegroundColor Green
                
                # Set description
                sc.exe description $serviceName "TARR Train Announcement Railroad Radio system - automated train station announcements"
                
                Write-Host "`nService Details:" -ForegroundColor Cyan
                Write-Host "- Name: $serviceName" -ForegroundColor White
                Write-Host "- Display Name: $serviceDisplayName" -ForegroundColor White
                Write-Host "- Start Type: Automatic" -ForegroundColor White
                Write-Host "- Path: $installDir\tarr-service.bat" -ForegroundColor White
                
                $startService = Read-Host "`nStart the service now? (Y/N)"
                if ($startService -eq "Y" -or $startService -eq "y") {
                    Write-Host "Starting TARR Annunciator service..." -ForegroundColor Yellow
                    sc.exe start $serviceName
                    if ($LASTEXITCODE -eq 0) {
                        Write-Host "✓ Service started successfully!" -ForegroundColor Green
                    } else {
                        Write-Host "⚠ Service failed to start" -ForegroundColor Yellow
                        Write-Host "You can start it manually: sc start $serviceName" -ForegroundColor White
                    }
                }
            } else {
                Write-Host "✗ Failed to install service" -ForegroundColor Red
                $adminRights = $false
            }
        } catch {
            Write-Host "✗ Error installing service: $($_.Exception.Message)" -ForegroundColor Red
            $adminRights = $false
        }
    }
} else {
    Write-Host "Service installation not available - not running as Administrator" -ForegroundColor Yellow
}

Write-Host "`n===============================================" -ForegroundColor Green
Write-Host "Installation Complete!" -ForegroundColor Green
Write-Host "===============================================" -ForegroundColor Green

if ($adminRights -and (Test-Path "tarr-service.bat")) {
    Write-Host "✓ TARR Annunciator installed as Windows service" -ForegroundColor Green
    Write-Host "The service will start automatically on boot" -ForegroundColor White
} else {
    Write-Host "✓ TARR Annunciator ready for manual operation" -ForegroundColor Green
}

Write-Host "`nAccess Points:" -ForegroundColor Cyan
Write-Host "- Web Interface: http://localhost:8080" -ForegroundColor White
Write-Host "- Admin Panel: http://localhost:8080/admin" -ForegroundColor White
Write-Host "- API Documentation: http://localhost:8080/api/docs" -ForegroundColor White

Write-Host "`nManual Operation:" -ForegroundColor Cyan
Write-Host "- Run: run_windows_go.bat" -ForegroundColor White
Write-Host "- Or directly: tarr-annunciator.exe" -ForegroundColor White

Write-Host "`nConfiguration:" -ForegroundColor Cyan
Write-Host "- Edit JSON files in json/ directory" -ForegroundColor White
Write-Host "- Access admin panel for web-based configuration" -ForegroundColor White

Write-Host "`nFirewall Note:" -ForegroundColor Yellow
Write-Host "Windows may prompt to allow network access for the application." -ForegroundColor White
Write-Host "Accept to enable web interface access." -ForegroundColor White

# Test audio if requested
$testAudio = Read-Host "`nTest audio system now? (Y/N)"
if ($testAudio -eq "Y" -or $testAudio -eq "y") {
    Write-Host "Testing audio system..." -ForegroundColor Yellow
    if (Test-Path "static\mp3\chime.mp3") {
        Write-Host "✓ Audio files found. You can test audio from the web interface at /admin" -ForegroundColor Green
    } else {
        Write-Host "⚠ Audio files not found. Please ensure all MP3 files are in place." -ForegroundColor Yellow
    }
}

Write-Host "`n✓ Installation completed successfully!" -ForegroundColor Green
Read-Host "`nPress Enter to exit"
